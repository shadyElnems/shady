# myapp/views.py
from django.shortcuts import render
from .models import LoginAttempt
from django.http import HttpResponse

def attempts_table(request):
    attempts = LoginAttempt.objects.all().order_by('-attempt_date')
    return render(request, 'myapp/attempts_table.html', {'attempts': attempts})



def dashboard(request):
    # فلترة حسب IP لو المستخدم كتب حاجة في خانة البحث
    ip_query = request.GET.get('ip', None)
    if ip_query:
        attempts = LoginAttempt.objects.filter(ip_address__icontains=ip_query)
    else:
        attempts = LoginAttempt.objects.all()

    return render(request, 'myapp/dashboard.html', {'attempts': attempts})
