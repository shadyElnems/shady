# myapp/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # path('', views.home, name='home'),  # المسار الفارغ
    path('attempts/', views.attempts_table, name='attempts_table'),
        path('', views.dashboard, name='dashboard'),

]
